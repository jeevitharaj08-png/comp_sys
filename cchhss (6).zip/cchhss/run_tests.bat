@echo off
echo Running Automated Verification Test Suite...
powershell -ExecutionPolicy Bypass -File test_system.ps1
pause
