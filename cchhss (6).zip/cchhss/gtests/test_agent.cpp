#include "test_helpers.h"

class AgentTest : public ::testing::Test {
protected:
    ScopedSandbox sandbox;

    void SetUp() override {
        initSystem();
    }

    void TearDown() override {
        freeAllMemory();
    }
};

/* ========================================================================= */
/* FUNCTION 20: agentDashboard Tests                                         */
/* ========================================================================= */

TEST_F(AgentTest, AgentDashboard_WorkloadCalculation) {
    // Populate complaints for AGT101 with ASSIGNED, RESOLVED, CLOSED, and one for AGT102
    freeAllMemory();
    sandbox.writeFile("data/complaints.txt",
        "CMP101|CUST1001|Cat|High|ASSIGNED|AGT101|2026-01-01|2026-01-01|2026-01-01|N/A|N/A|N/A|Note|1\n"
        "CMP102|CUST1001|Cat|High|RESOLVED|AGT101|2026-01-01|2026-01-01|2026-01-01|2026-01-01|N/A|N/A|Note|2\n"
        "CMP103|CUST1001|Cat|High|CLOSED|AGT101|2026-01-01|2026-01-01|2026-01-01|2026-01-01|2026-01-01|N/A|Note|3\n"
        "CMP104|CUST1001|Cat|High|ASSIGNED|AGT102|2026-01-01|2026-01-01|2026-01-01|N/A|N/A|N/A|Note|4\n");
    initSystem();

    StdioCapture capture("4\n"); // Choice 4: Logout
    agentDashboard(0); // AGT101

    std::string out = capture.getOutput();
    EXPECT_NE(out.find("Active Workload: 1"), std::string::npos);
}

TEST_F(AgentTest, AgentDashboard_SubmenuDispatchAndLogout) {
    freeAllMemory();
    sandbox.writeFile("data/complaints.txt",
        "CMP101|CUST1001|Technical Support|High|ASSIGNED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Desc\n");
    sandbox.writeFile("data/audit_log.txt",
        "CMP101|2026-01-01 10:00:00|REGISTERED|CUST1001|Created\n");
    initSystem();

    // 1: View assigned, 2: Update complaint (cancel via 4), 3: View history (missing CMP999),
    // 3: View history (found CMP101), 4: Logout
    StdioCapture capture("1\n2\nCMP101\n4\n3\nCMP999\n3\nCMP101\n4\n");
    agentDashboard(0);

    std::string out = capture.getOutput();
    EXPECT_NE(out.find("Assigned Complaints for AGT101"), std::string::npos);
    EXPECT_NE(out.find("Action cancelled"), std::string::npos);
    EXPECT_NE(out.find("Error: Complaint ID 'CMP999' not found"), std::string::npos);
    EXPECT_NE(out.find("Audit History for CMP101"), std::string::npos);
    EXPECT_NE(out.find("REGISTERED"), std::string::npos);
}

/* ========================================================================= */
/* FUNCTION 21: agentViewAssigned Tests                                      */
/* ========================================================================= */

TEST_F(AgentTest, AgentViewAssigned_ZeroComplaints) {
    StdioCapture capture;
    agentViewAssigned("AGT101");

    EXPECT_NE(capture.getOutput().find("No complaints are currently assigned to you"), std::string::npos);
}

TEST_F(AgentTest, AgentViewAssigned_MultipleComplaintsWithIsolation) {
    freeAllMemory();
    sandbox.writeFile("data/complaints.txt",
        "CMP101|CUST1001|Technical Support|High|ASSIGNED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Ticket 1\n"
        "CMP102|CUST1002|Billing and Account|Low|IN_PROGRESS|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Ticket 2\n"
        "CMP103|CUST1003|Customer Service|High|ASSIGNED|AGT102|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Ticket 3\n");
    initSystem();

    StdioCapture capture;
    agentViewAssigned("AGT101");

    std::string out = capture.getOutput();
    EXPECT_NE(out.find("CMP101"), std::string::npos);
    EXPECT_NE(out.find("CMP102"), std::string::npos);
    EXPECT_EQ(out.find("CMP103"), std::string::npos); // Isolated AGT102
    EXPECT_NE(out.find("Total Assigned: 2"), std::string::npos);
}

/* ========================================================================= */
/* FUNCTION 22: agentUpdateComplaint Tests                                   */
/* ========================================================================= */

TEST_F(AgentTest, AgentUpdateComplaint_NotFoundAndNotAssigned) {
    // 1. Complaint not found
    {
        StdioCapture capture("CMP999\n");
        agentUpdateComplaint("AGT101");
        EXPECT_NE(capture.getOutput().find("Error: Complaint ID 'CMP999' not found"), std::string::npos);
    }
    // 2. Complaint assigned to another agent
    {
        freeAllMemory();
        sandbox.writeFile("data/complaints.txt",
            "CMP101|CUST1001|Technical Support|High|ASSIGNED|AGT102|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Desc\n");
        initSystem();

        StdioCapture capture("CMP101\n");
        agentUpdateComplaint("AGT101");
        EXPECT_NE(capture.getOutput().find("is not assigned to you (Assigned to: AGT102)"), std::string::npos);
    }
}

TEST_F(AgentTest, AgentUpdateComplaint_CancelAction) {
    freeAllMemory();
    sandbox.writeFile("data/complaints.txt",
        "CMP101|CUST1001|Technical Support|High|ASSIGNED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Desc\n");
    initSystem();

    StdioCapture capture("CMP101\n4\n"); // Choice 4: Cancel
    agentUpdateComplaint("AGT101");
    EXPECT_NE(capture.getOutput().find("Action cancelled"), std::string::npos);
}

TEST_F(AgentTest, AgentUpdateComplaint_StatusTransitionsAndResolvedCounters) {
    // 1. Status 1: IN_PROGRESS (empty note triggers default note string)
    {
        freeAllMemory();
        sandbox.writeFile("data/complaints.txt",
            "CMP101|CUST1001|Technical Support|High|ASSIGNED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Desc\n");
        initSystem();

        StdioCapture capture("CMP101\n1\n\n");
        agentUpdateComplaint("AGT101");
        ComplaintNode *node = findComplaintById("CMP101");
        ASSERT_NE(node, nullptr);
        EXPECT_STREQ(node->data.status, "IN_PROGRESS");
        EXPECT_STREQ(node->data.lastNote, "Status updated by AGT101");
    }
    // 2. Status 2: RESOLVED for AGT102 (exercises loop index i=0 false, i=1 true)
    {
        freeAllMemory();
        sandbox.writeFile("data/complaints.txt",
            "CMP101|CUST1001|Technical Support|High|ASSIGNED|AGT102|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Desc\n");
        initSystem();

        StdioCapture capture("CMP101\n2\nFixed issue\n");
        agentUpdateComplaint("AGT102");
        ComplaintNode *node = findComplaintById("CMP101");
        ASSERT_NE(node, nullptr);
        EXPECT_STREQ(node->data.status, "RESOLVED");
        EXPECT_STRNE(node->data.timestamps.resolved, "N/A");
    }
    // 3. Status 2: RESOLVED for AGT_UNKNOWN (loops through all 10 agents without match)
    {
        freeAllMemory();
        sandbox.writeFile("data/complaints.txt",
            "CMP101|CUST1001|Technical Support|High|ASSIGNED|AGT_UNKNOWN|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Desc\n");
        initSystem();

        StdioCapture capture("CMP101\n2\nResolved\n");
        agentUpdateComplaint("AGT_UNKNOWN");
        ComplaintNode *node = findComplaintById("CMP101");
        ASSERT_NE(node, nullptr);
        EXPECT_STREQ(node->data.status, "RESOLVED");
    }
    // 4. Status 3: ESCALATED with timestamp
    {
        freeAllMemory();
        sandbox.writeFile("data/complaints.txt",
            "CMP101|CUST1001|Technical Support|High|ASSIGNED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Desc\n");
        initSystem();

        StdioCapture capture("CMP101\n3\nRequires Senior Review\n");
        agentUpdateComplaint("AGT101");
        ComplaintNode *node = findComplaintById("CMP101");
        ASSERT_NE(node, nullptr);
        EXPECT_STREQ(node->data.status, "ESCALATED");
        EXPECT_STRNE(node->data.timestamps.escalated, "N/A");
    }
}
