# Complaint Handling System in C11

A robust, modular, and menu-driven console-based Complaint Handling System built using standard **C11**, **GCC**, **nested structures**, **arrays**, **singly linked lists**, and **persistent file handling**.

---

## 1. Compliance Matrix

| Constraint | Requirement | Status | Implementation Details |
| :--- | :--- | :---: | :--- |
| **Technology Stack** | Standard C11, GCC, `<time.h>` | **PASS** | Compiled with `gcc -std=c11 -Wall -Wextra -pedantic` with zero warnings. |
| **Main Menu Options** | Exactly 4 options: Customer, Agent, Manager, Exit | **PASS** | Exact prompt format matched with safe input validation. |
| **Function Count** | Between 20 and 30 functions including `main()` | **PASS** | **Exactly 29 application-defined functions**. |
| **Complaint Sequence** | Starts strictly at `CMP101`, followed by `CMP102`, etc. | **PASS** | Verified; sequence persists across application restarts. |
| **Initial Production State**| Zero complaints, zero dummy records, zero demo history | **PASS** | Verified; files initialize with 0 complaints and 0 customers. |
| **Agent Accounts** | 10 predefined agents (`AGT101`-`AGT110`) | **PASS** | Predefined agents initialized in persistent storage. |
| **Manager Account** | 1 predefined manager account | **PASS** | Initialized as `manager` / `manager123`. |
| **Data Structures** | Nested structures, arrays, singly linked lists | **PASS** | `ComplaintTimestamps` nested in `Complaint`; `AuditNode`, `ComplaintNode`, and `CustomerNode` singly linked lists. |
| **Security & Privacy** | Password masking & cross-customer data isolation | **PASS** | Customers can only view their own records; agent passwords never displayed in reports or UI. |

---

## 2. Main Menu

```text
========================================
       COMPLAINT HANDLING SYSTEM
========================================

1. Customer
2. Agent
3. Manager
4. Exit

Enter your choice:
```

---

## 3. Predefined Credentials

### Manager Account
- **Username:** `manager`
- **Password:** `manager123`
- **Name:** Operations Manager

### Support Agents (10 Predefined Agents)
*Note: Per security guidelines, passwords are documented below for demonstration and testing purposes only, and are never displayed on screens, dashboards, or managerial reports.*

| Agent ID | Full Name | Username | Password | Default Status |
| :---: | :--- | :---: | :---: | :---: |
| `AGT101` | Alice Smith | `agent1` | `agentpass1` | ACTIVE |
| `AGT102` | Bob Johnson | `agent2` | `agentpass2` | ACTIVE |
| `AGT103` | Charlie Brown | `agent3` | `agentpass3` | ACTIVE |
| `AGT104` | Diana Prince | `agent4` | `agentpass4` | ACTIVE |
| `AGT105` | Edward Stark | `agent5` | `agentpass5` | ACTIVE |
| `AGT106` | Fiona Gallagher | `agent6` | `agentpass6` | ACTIVE |
| `AGT107` | George Clark | `agent7` | `agentpass7` | ACTIVE |
| `AGT108` | Hannah Abbott | `agent8` | `agentpass8` | ACTIVE |
| `AGT109` | Ian Malcolm | `agent9` | `agentpass9` | ACTIVE |
| `AGT110` | Julia Roberts | `agent10` | `agentpass10` | ACTIVE |

---

## 4. Application-Defined Function Inventory (29 Functions)

The codebase strictly contains **29 application-defined functions** (within the mandatory [20, 30] constraint):

| # | Function Signature | Description |
| :-: | :--- | :--- |
| 1 | `void getTimestamp(char *buffer, size_t size)` | Formats current system time to `YYYY-MM-DD HH:MM:SS` using `<time.h>`. |
| 2 | `void readString(const char *prompt, char *buffer, size_t size)` | Safely reads string from `stdin`, strips newlines, and prevents delimiter collisions. |
| 3 | `int readInt(const char *prompt, int minVal, int maxVal)` | Robust integer input parser validating ranges and preventing infinite loops on invalid input. |
| 4 | `CustomerNode* findCustomerByUsername(const char *username)` | Traverses customer singly linked list to find an account by unique username. |
| 5 | `ComplaintNode* findComplaintById(const char *complaintId)` | Traverses complaint singly linked list to locate record by complaint ID. |
| 6 | `void addAuditEntry(ComplaintNode *node, const char *action, const char *by, const char *details)` | Dynamically allocates and appends a chronological audit event node to a complaint. |
| 7 | `int autoAssignAgent(void)` | Identifies the active agent with the least open workload for load-balanced assignment. |
| 8 | `void initSystem(void)` | Initializes directories, loads or provisions 10 agents, counters, customers, complaints, and audit nodes. |
| 9 | `void saveAllData(void)` | Flushes all linked lists, agent stats, and sequence counters to persistent storage files. |
| 10 | `void freeAllMemory(void)` | Releases all dynamically allocated memory (customers, complaints, and audit nodes) upon exit. |
| 11 | `void customerMenu(void)` | Manages pre-login customer portal (Register, Login, Return). |
| 12 | `void customerRegister(void)` | Registers new customer (`CUST1001`+), verifies username uniqueness, saves data persistently without creating complaints. |
| 13 | `void customerLogin(void)` | Authenticates customer credentials and launches customer dashboard. |
| 14 | `void customerDashboard(const char *customerId, const char *customerName)` | Logged-in customer menu (Register complaint, View my, Track by ID, Audit history, Logout). |
| 15 | `void customerRegisterComplaint(const char *customerId)` | Creates complaint with sequential ID (`CMP101`+), category, priority, auto-assigned agent, and audit log. |
| 16 | `void customerViewComplaints(const char *customerId)` | Renders tabular summary of all complaints belonging exclusively to the logged-in customer. |
| 17 | `void customerTrackComplaint(const char *customerId)` | Displays comprehensive status card, progress timeline, and stage progression indicator. |
| 18 | `void customerViewHistory(const char *customerId)` | Renders full chronological audit trail of actions taken on a specific customer complaint. |
| 19 | `void agentMenu(void)` | Pre-login agent portal (Login, Return). |
| 20 | `void agentDashboard(int agentIdx)` | Logged-in agent dashboard displaying live workload, resolved metrics, and ticket tools. |
| 21 | `void agentViewAssigned(const char *agentId)` | Lists all complaints currently assigned to the logged-in support agent. |
| 22 | `void agentUpdateComplaint(const char *agentId)` | Allows agent to progress complaint (`IN_PROGRESS`, `RESOLVED`, `ESCALATED`) with notes and timestamps. |
| 23 | `void managerMenu(void)` | Pre-login manager portal (Login, Return). |
| 24 | `void managerDashboard(void)` | Manager control panel with system metrics, assignment tools, status controls, and audit logs. |
| 25 | `void managerViewAllComplaints(void)` | Renders executive KPI metrics summary (Total, Pending, Assigned, In Progress, Resolved, Closed, Escalated) and list. |
| 26 | `void managerAssignComplaint(void)` | Allows manager to manually assign or reassign any complaint to an active agent. |
| 27 | `void managerUpdateComplaint(void)` | Administrative complaint transition (In Progress, Resolved, Closed, Escalated) with notes and timestamps. |
| 28 | `void managerAgentManagement(void)` | Displays agent roster with live workloads, resolved totals, and enables toggling Active/Inactive status. |
| 29 | `int main(void)` | Application entry point executing initialization, main loop, and graceful memory deallocation on exit. |

---

## 5. Data Structures & System Architecture

```text
  CustomerNode (Singly Linked List)
  ┌───────────────┬────────────┐
  │ Customer Data │ Next Node* ├──► [Next Customer] ──► NULL
  └───────────────┴────────────┘

  ComplaintNode (Singly Linked List)
  ┌────────────────────────────────────────────────────────┐
  │ Complaint Data                                         │
  │  - complaintId ("CMP101")                              │
  │  - customerId  ("CUST1001")                            │
  │  - category, priority, status, assignedAgentId         │
  │  - ComplaintTimestamps (Nested Structure)              │
  │      registered, assigned, updated, resolved, closed   │
  │  - auditHead* ─────────┐                               │
  │  - next* ────────┐     │                               │
  └──────────────────┼─────┼───────────────────────────────┘
                     │     ▼
                     │   AuditNode (Singly Linked List)
                     │   ┌─────────────────────────────┐
                     │   │ Timestamp | Action | Detail ├──► [Next Audit] ──► NULL
                     │   └─────────────────────────────┘
                     ▼
             [Next Complaint] ──► NULL
```

### Complaint Categories
1. Technical Support
2. Billing and Account
3. Customer Service
4. Logistics Support
5. Other

### Complaint Priorities
1. Low
2. Medium
3. High
4. Critical

### Complaint Lifecycle Statuses
`PENDING` &rarr; `ASSIGNED` &rarr; `IN_PROGRESS` &rarr; `RESOLVED` &rarr; `CLOSED` *(or `ESCALATED`)*

---

## 6. Directory Structure

```text
cchhss/
├── include/
│   └── complaint_system.h    # Header with struct definitions, macros, and prototypes
├── src/
│   └── main.c                # All 29 function definitions implemented in clean C11
├── data/                     # Persistent storage created on first launch
│   ├── agents.txt            # 10 predefined agents and metrics
│   ├── audit_log.txt         # Chronological audit trail
│   ├── complaints.txt        # All complaints with nested timestamps
│   ├── counters.txt          # Sequence tracking (starts strictly at CMP101)
│   └── customers.txt         # Registered customer profiles
├── build.bat                 # 1-click Windows compilation script
├── run.bat                   # 1-click execution script
├── run_tests.bat             # 1-click test suite launcher
├── test_system.ps1           # Comprehensive automated PowerShell verification suite
├── Makefile                  # Standard Makefile for GCC
└── README.md                 # Complete documentation
```

---

## 7. Compilation & Execution

### Option A: Using Batch Scripts (Windows)
```cmd
build.bat
run.bat
```

### Option B: Using GCC directly
```bash
gcc -std=c11 -Wall -Wextra -pedantic -Iinclude -o complaint_system.exe src/main.c
./complaint_system.exe
```

### Option C: Using Make
```bash
make
./complaint_system.exe
```

### Running Automated Verification Suite
```cmd
run_tests.bat
```
or in PowerShell:
```powershell
powershell -ExecutionPolicy Bypass -File test_system.ps1
```

---

## 8. Step-by-Step Demonstration Walkthrough

1. **Clean First Launch:**
   - Launch application &rarr; Notice 4 main menu options.
   - Enter `4` to Exit &rarr; Verify `data/complaints.txt` has 0 complaints.
2. **Customer Registration:**
   - Launch application &rarr; Enter `1` (Customer) &rarr; `1` (Register).
   - Enter details &rarr; Assigned Customer ID is `CUST1001`. Notice zero complaints were created.
3. **Complaint Registration & Sequential ID:**
   - Login as `CUST1001` &rarr; Choose `1` (Register a complaint).
   - Select Category and Priority, enter description.
   - The complaint receives ID **`CMP101`** and is auto-assigned to active agent `AGT101`.
   - Register a second complaint &rarr; Receives ID **`CMP102`** and assigned to `AGT102`.
4. **Agent Investigation & Resolution:**
   - Return to main menu &rarr; Enter `2` (Agent) &rarr; Login with `agent1` / `agentpass1`.
   - View assigned &rarr; Complaint `CMP101` appears.
   - Update status to `IN_PROGRESS` and add diagnostic note.
   - Update status to `RESOLVED` and add resolution note.
5. **Manager Governance & Dashboard:**
   - Return to main menu &rarr; Enter `3` (Manager) &rarr; Login with `manager` / `manager123`.
   - View Dashboard &rarr; Observe real-time KPI counts (Total, In Progress, Resolved).
   - Reassign `CMP102` to `AGT103` (Charlie Brown).
   - Update `CMP101` status to `CLOSED`.
   - Open Agent Management &rarr; Toggle `AGT104` to `INACTIVE`.
   - View complete system audit log &rarr; Inspect full audit trail.
6. **Persistence & Continuation:**
   - Exit application (`4`).
   - Launch again &rarr; Register a complaint &rarr; Next complaint is strictly **`CMP103`**.
