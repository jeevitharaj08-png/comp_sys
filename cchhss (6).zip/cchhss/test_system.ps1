# ==============================================================================
# Automated Verification & Test Suite for Complaint Handling System (C11)
# ==============================================================================

$ErrorActionPreference = "Stop"

Write-Host "`n=== COMPLAINT HANDLING SYSTEM: VERIFICATION SUITE ===" -ForegroundColor Cyan

# 1. Compile Check
Write-Host "`n[1/7] Compiling application using GCC C11 standard..." -ForegroundColor Yellow
$compileCmd = "gcc -std=c11 -Wall -Wextra -pedantic -Iinclude -o complaint_system.exe src/main.c"
Invoke-Expression $compileCmd
if ($LASTEXITCODE -ne 0) {
    Write-Error "Compilation failed."
    exit 1
}
Write-Host " Compilation SUCCESSFUL with zero warnings and zero errors." -ForegroundColor Green

# 2. Function Count Check
Write-Host "`n[2/7] Checking application-defined function count..." -ForegroundColor Yellow
$txt = Get-Content 'src/main.c' -Raw
$pattern = '(?m)^[a-zA-Z_][a-zA-Z0-9_\* ]+?\s+([a-zA-Z0-9_]+)\s*\([^;{}]*\)\s*\{'
$allMatches = [regex]::Matches($txt, $pattern)
$funcCount = $allMatches.Count
Write-Host " Total application-defined functions found: $funcCount" -ForegroundColor White
foreach ($m in $allMatches) {
    Write-Host "   - $($m.Groups[1].Value)()" -ForegroundColor DarkGray
}

if ($funcCount -ge 20 -and $funcCount -le 30) {
    Write-Host " Function count ($funcCount) is strictly between 20 and 30 as mandated." -ForegroundColor Green
} else {
    Write-Error "Function count ($funcCount) violates the constraint [20, 30]!"
    exit 1
}

# 3. Clean State Verification
Write-Host "`n[3/7] Verifying initial clean state (zero complaints)..." -ForegroundColor Yellow
if (Test-Path 'data') { Remove-Item -Recurse -Force 'data' }
$initInput = "4`n"
$output = $initInput | .\complaint_system.exe
if ((Get-Content "data/complaints.txt").Length -eq 0 -and (Get-Content "data/customers.txt").Length -eq 0) {
    Write-Host " Initial state verified: Zero complaints and zero customers." -ForegroundColor Green
} else {
    Write-Error "Initial data files contain unexpected records."
    exit 1
}

# 4. Customer Registration and Zero-Complaint Invariant
Write-Host "`n[4/7] Testing customer registration (must not create complaints)..." -ForegroundColor Yellow
$custInput = @(
    '1',                # Main Menu -> Customer
    '1',                # Register
    'Alice Johnson',    # Name
    'alice',            # Username
    'alice123',         # Password
    'alice@test.com',   # Contact
    '1',                # Register next customer
    'Bob Smith',        # Name
    'bob',              # Username
    'bob123',           # Password
    'bob@test.com',     # Contact
    '3',                # Return to Main Menu
    '4'                 # Exit
) -join "`n"
$custInput | .\complaint_system.exe | Out-Null

$custLines = Get-Content "data/customers.txt"
$compLines = (Get-Content "data/complaints.txt").Length
if ($custLines.Count -eq 2 -and $compLines -eq 0) {
    Write-Host " Customer accounts CUST1001 and CUST1002 registered." -ForegroundColor Green
    Write-Host " Zero complaints created during registration invariant preserved." -ForegroundColor Green
} else {
    Write-Error "Customer registration test failed."
    exit 1
}

# 5. Complaint Registration & Sequential ID Generation (CMP101, CMP102)
Write-Host "`n[5/7] Testing complaint registration and ID generation (CMP101, CMP102)..." -ForegroundColor Yellow
$compInput = @(
    '1',                # Main Menu -> Customer
    '2',                # Login
    'alice',
    'alice123',
    '1',                # Register complaint 1
    '1',                # Category: Technical Support
    '3',                # Priority: High
    'Fiber internet line disconnected.',
    '1',                # Register complaint 2
    '2',                # Category: Billing and Account
    '2',                # Priority: Medium
    'Billing dispute for extra data charges.',
    '5',                # Logout
    '3',                # Return
    '4'                 # Exit
) -join "`n"
$compOutput = ($compInput | .\complaint_system.exe) -join "`n"

if ($compOutput -match "CMP101" -and $compOutput -match "CMP102") {
    Write-Host " Verified sequential complaint ID generation: CMP101, then CMP102." -ForegroundColor Green
} else {
    Write-Error "Sequential complaint ID verification failed."
    exit 1
}

# 6. Agent and Manager Workflows, Authorization, and Audit Logs
Write-Host "`n[6/7] Testing agent resolution, manager reassignment, and access control..." -ForegroundColor Yellow
$agentMgrInput = @(
    '2',                # Main Menu -> Agent
    '1',                # Agent Login
    'agent1',
    'agentpass1',
    '2',                # Update status
    'CMP101',
    '1',                # In Progress
    'Dispatched technician to site.',
    '2',                # Update status
    'CMP101',
    '2',                # Resolved
    'Replaced faulty cable transceiver.',
    '4',                # Logout Agent
    '2',                # Return to Main Menu
    '1',                # Main Menu -> Customer
    '2',                # Customer Login
    'bob',
    'bob123',
    '3',                # Track complaint
    'CMP101',           # Bob attempts to view Alice's complaint
    '5',                # Logout Bob
    '3',                # Return to Main Menu
    '3',                # Main Menu -> Manager
    '1',                # Manager Login
    'manager',
    'manager123',
    '2',                # Reassign complaint
    'CMP102',
    'AGT103',           # Reassign CMP102 to AGT103
    '3',                # Update complaint
    'CMP101',
    '3',                # Mark CLOSED
    'Closed ticket after customer confirmation.',
    '6',                # Logout Manager
    '2',                # Return to Main Menu
    '4'                 # Exit
) -join "`n"
$agentMgrOutput = ($agentMgrInput | .\complaint_system.exe) -join "`n"

if ($agentMgrOutput -match "Security violation" -and $agentMgrOutput -match "successfully assigned to AGT103") {
    Write-Host " Authorization security verified (cross-customer access denied)." -ForegroundColor Green
    Write-Host " Agent resolution and Manager reassignment verified." -ForegroundColor Green
} else {
    Write-Error "Agent/Manager workflow verification failed."
    exit 1
}

# 7. Persistence Across Restart: Next ID must be CMP103
Write-Host "`n[7/7] Testing persistence across restart (Next ID must be CMP103)..." -ForegroundColor Yellow
$restartInput = @(
    '1',                # Main Menu -> Customer
    '2',                # Login
    'bob',
    'bob123',
    '1',                # Register new complaint
    '3',                # Category: Customer Service
    '1',                # Priority: Low
    'General inquiry on account statements.',
    '5',                # Logout
    '3',                # Return
    '4'                 # Exit
) -join "`n"
$restartOutput = ($restartInput | .\complaint_system.exe) -join "`n"

if ($restartOutput -match "CMP103") {
    Write-Host " Persistence verified: Next complaint issued is strictly CMP103." -ForegroundColor Green
} else {
    Write-Error "Persistence verification failed. Expected CMP103."
    exit 1
}

# Reset data to clean state with 0 complaints as required for production
Write-Host "`nResetting system to clean production state (zero complaints)..." -ForegroundColor Yellow
if (Test-Path 'data') { Remove-Item -Recurse -Force 'data' }
$cleanExit = "4`n"
$cleanExit | .\complaint_system.exe | Out-Null

Write-Host "`n========================================================" -ForegroundColor Cyan
Write-Host " ALL TEST SUITES PASSED CLEANLY! SYSTEM IS 100% READY." -ForegroundColor Green
Write-Host "========================================================`n" -ForegroundColor Cyan
